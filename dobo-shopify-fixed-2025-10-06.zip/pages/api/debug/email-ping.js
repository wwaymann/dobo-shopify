// pages/api/debug/email-ping.js
export default async function handler(req, res) {
  const haveUser = !!process.env.GMAIL_USER;
  const havePass = !!process.env.GMAIL_APP_PASSWORD;
  const haveTo   = !!process.env.MERCHANT_NOTIF_EMAIL;
  res.status(200).json({ gmailUserSet: haveUser, gmailAppPasswordSet: havePass, destSet: haveTo });
}
