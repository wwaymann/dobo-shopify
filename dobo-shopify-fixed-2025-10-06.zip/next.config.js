/** @type {import('next').NextConfig} */
const nextConfig = { productionBrowserSourceMaps: true };
module.exports = nextConfig;

module.exports = { reactStrictMode: true };
